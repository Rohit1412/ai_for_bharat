"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/index.ts
var src_exports = {};
__export(src_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(src_exports);
var import_client_dynamodb = require("@aws-sdk/client-dynamodb");
var import_lib_dynamodb = require("@aws-sdk/lib-dynamodb");
var import_client_s3 = require("@aws-sdk/client-s3");
var import_client_sns = require("@aws-sdk/client-sns");
var REGION = process.env.AWS_REGION ?? "us-east-1";
var GEMINI_API_KEY = process.env.GEMINI_API_KEY ?? "";
var GEMINI_MODEL = "gemini-2.5-flash";
var ALERTS_TABLE = process.env.ALERTS_TABLE ?? "viriva-alerts";
var INTERVENTIONS_TABLE = process.env.INTERVENTIONS_TABLE ?? "viriva-interventions";
var ACTION_PLANS_TABLE = process.env.ACTION_PLANS_TABLE ?? "viriva-action-plans";
var CHAT_HISTORY_TABLE = process.env.CHAT_HISTORY_TABLE ?? "viriva-chat-history";
var S3_DATA_BUCKET = process.env.S3_BUCKET_DATA ?? "viriva-data-dev";
var SNS_TOPIC_ARN = process.env.SNS_TOPIC_ARN ?? "";
var dynamo = import_lib_dynamodb.DynamoDBDocumentClient.from(new import_client_dynamodb.DynamoDBClient({ region: REGION }));
var s3 = new import_client_s3.S3Client({ region: REGION });
var sns = new import_client_sns.SNSClient({ region: REGION });
async function invokeGemini(prompt, systemMessage = "You are ClimateAI, an expert climate action coordinator.") {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`;
  const body = {
    system_instruction: { parts: [{ text: systemMessage }] },
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    generationConfig: { maxOutputTokens: 1500, temperature: 0.7 }
  };
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if (data.error) throw new Error(`Gemini error: ${data.error.message}`);
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error(`Gemini no content: ${JSON.stringify(data).slice(0, 200)}`);
  return text;
}
function ok(body, status = 200) {
  return {
    statusCode: status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type,Authorization",
      "Access-Control-Allow-Methods": "GET,POST,OPTIONS"
    },
    body: JSON.stringify(body)
  };
}
function err(message, status = 500) {
  return ok({ success: false, error: message }, status);
}
function parseBody(event) {
  return JSON.parse(event.body ?? "{}");
}
var INTERVENTIONS_FALLBACK = [
  { id: "int_1", name: "Solar Agri-Pumps", carbon_reduction_tco2e: 250, cost_range: "\u20B960K\u2013\u20B985K", equity_score: 85, water_savings_percent: 25, timeline_months: 2, priority: "high" },
  { id: "int_2", name: "Direct Seeded Rice", carbon_reduction_tco2e: 380, cost_range: "\u20B915K\u2013\u20B925K", equity_score: 90, water_savings_percent: 30, timeline_months: 3, priority: "critical" },
  { id: "int_3", name: "Residue-to-Biogas", carbon_reduction_tco2e: 180, cost_range: "\u20B950K\u2013\u20B995K", equity_score: 75, water_savings_percent: 0, timeline_months: 4, priority: "medium" },
  { id: "int_4", name: "Dairy Methane Digesters", carbon_reduction_tco2e: 120, cost_range: "\u20B980K\u2013\u20B91.1L", equity_score: 70, water_savings_percent: 5, timeline_months: 5, priority: "medium" },
  { id: "int_5", name: "Reforestation", carbon_reduction_tco2e: 150, cost_range: "\u20B95K\u2013\u20B915K", equity_score: 95, water_savings_percent: 10, timeline_months: 12, priority: "low" }
];
var ALERTS_FALLBACK = [
  { id: "a1", region: "Raichur", severity: "high", message: "Methane spike in paddy fields (Sentinel-5P)", recommended_action: "Switch 15% paddy to DSR" },
  { id: "a2", region: "Chikkaballapur", severity: "critical", message: "Groundwater depth 8.2m \u2014 threshold exceeded", recommended_action: "Deploy solar agri-pumps with drip irrigation" },
  { id: "a3", region: "Karnataka", severity: "medium", message: "Temp 2.1\xB0C above seasonal avg \u2014 heat stress for rabi crops", recommended_action: "Issue heat advisory; recommend protective irrigation" }
];
async function handleHealth() {
  return ok({
    status: "healthy",
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    service: "climateai-backend",
    region: REGION,
    version: "2.0.0",
    aws_services: ["lambda", "bedrock", "dynamodb", "s3", "sns"]
  });
}
async function handleRoot() {
  return ok({
    service: "ClimateAI Global Coordinator \u2014 AWS Backend",
    version: "2.0.0",
    region: REGION,
    aws_services: ["Lambda", "API Gateway", "DynamoDB", "S3", "SNS", "Bedrock"],
    ai_model: GEMINI_MODEL,
    endpoints: [
      "/health",
      "/api/chat",
      "/api/action-plan/generate",
      "/api/interventions",
      "/api/alerts",
      "/api/kpis",
      "/api/data/validate",
      "/api/data/upload"
    ]
  });
}
async function handleChat(event) {
  const { question, language = "english", context } = parseBody(event);
  if (!question) return err("question is required", 400);
  const languageNote = language === "kannada" ? "Respond in KANNADA." : "Respond in clear English.";
  const contextNote = context ? `
Context: ${JSON.stringify(context)}` : "";
  const prompt = `You are ClimateAI, an expert climate action coordinator for India.
${languageNote}
User question: ${question}${contextNote}

Provide a concise, practical answer (under 200 words) based on verified climate science.
Include India-specific government schemes or subsidies when relevant.`;
  try {
    const answer = await invokeGemini(
      prompt,
      "You are ClimateAI \u2013 a knowledgeable, action-oriented climate assistant."
    );
    try {
      await dynamo.send(new import_lib_dynamodb.PutCommand({
        TableName: CHAT_HISTORY_TABLE,
        Item: {
          chat_id: crypto.randomUUID(),
          question,
          answer,
          timestamp: Date.now(),
          language,
          source: "bedrock-claude"
        }
      }));
    } catch {
    }
    return ok({ success: true, answer, powered_by: "aws-bedrock", model: GEMINI_MODEL });
  } catch (e) {
    return err(`Chat error: ${e.message}`);
  }
}
async function handleGenerateActionPlan(event) {
  const { intervention_ids, region = "Karnataka", budget_limit } = parseBody(event);
  const prompt = `You are a climate action planner for rural India.
Region: ${region}
Selected interventions: ${intervention_ids.join(", ")}
Budget limit: ${budget_limit ?? "No limit"}

Generate a ranked action plan as JSON:
{
  "ranked_portfolio": [{"rank": 1, "name": "...", "reason": "...", "co2_reduction": 0, "cost": 0}],
  "trade_off_analysis": "...",
  "timeline": "...",
  "recommendations": ["..."],
  "confidence_scores": {"climate_impact": 0.9, "feasibility": 0.8, "equity": 0.85}
}`;
  try {
    const explanation = await invokeGemini(
      prompt,
      "You are an expert climate action planner. Return valid JSON only."
    );
    const planId = `plan-${Date.now()}`;
    try {
      await dynamo.send(new import_lib_dynamodb.PutCommand({
        TableName: ACTION_PLANS_TABLE,
        Item: {
          plan_id: planId,
          region,
          selected_interventions: intervention_ids,
          ai_explanation: explanation,
          created_at: Date.now(),
          status: "generated"
        }
      }));
    } catch {
    }
    return ok({
      success: true,
      action_plan_id: planId,
      explanation,
      region,
      interventions_count: intervention_ids.length,
      powered_by: "aws-bedrock"
    });
  } catch (e) {
    return err(`Plan generation error: ${e.message}`);
  }
}
async function handleGetInterventions() {
  try {
    const result = await dynamo.send(new import_lib_dynamodb.ScanCommand({ TableName: INTERVENTIONS_TABLE, Limit: 20 }));
    if (result.Items?.length) {
      return ok({ success: true, interventions: result.Items });
    }
  } catch {
  }
  return ok({ success: true, interventions: INTERVENTIONS_FALLBACK });
}
async function handleGetAlerts(event) {
  const region = event.queryStringParameters?.region ?? "Karnataka";
  try {
    const result = await dynamo.send(new import_lib_dynamodb.QueryCommand({
      TableName: ALERTS_TABLE,
      KeyConditionExpression: "region = :r",
      ExpressionAttributeValues: { ":r": region },
      ScanIndexForward: false,
      Limit: 10
    }));
    if (result.Items?.length) {
      return ok({ success: true, region, alerts: result.Items });
    }
  } catch {
  }
  return ok({ success: true, region, alerts: ALERTS_FALLBACK });
}
async function handleCreateAlert(event) {
  const { metric, threshold, region } = parseBody(event);
  try {
    const item = {
      id: `alert-${Date.now()}`,
      region,
      metric,
      threshold: String(threshold),
      created_at: Date.now(),
      status: "active"
    };
    await dynamo.send(new import_lib_dynamodb.PutCommand({ TableName: ALERTS_TABLE, Item: item }));
    return ok({ success: true, alert_id: item.id });
  } catch (e) {
    return err(e.message);
  }
}
async function handleNotifyAlert(event) {
  const { alert_id, message } = parseBody(event);
  if (!SNS_TOPIC_ARN) return ok({ success: false, message: "SNS_TOPIC_ARN not configured" });
  try {
    await sns.send(new import_client_sns.PublishCommand({
      TopicArn: SNS_TOPIC_ARN,
      Subject: `ClimateAI Alert: ${alert_id}`,
      Message: message
    }));
    return ok({ success: true, alert_id });
  } catch (e) {
    return err(e.message);
  }
}
async function handleGetKPIs() {
  return ok({
    emissions_trend: { current: 45.2, target: 40, unit: "MtCO2e", change_percent: -12 },
    carbon_budget: { current: 1.8, total: 2.5, unit: "GtCO2e", remaining_percent: 72 },
    temp_rise_2030: { projection: 1.4, target: 1.2, unit: "\xB0C", change_percent: 16.7 },
    water_risk_score: { current: 78, scale: 100, unit: "Score", change_percent: 5 },
    total_paddy_ha: 45e4,
    annual_methane_tco2e: 201e5,
    active_projects: 20,
    projected_impact_tco2e: -28e5
  });
}
async function handleValidateData(event) {
  const data = parseBody(event);
  try {
    const prompt = `Validate this climate data and assign confidence scores (0\u2013100):
${JSON.stringify(data, null, 2)}

Return JSON: {"validated_fields": {}, "issues": [], "overall_confidence_score": 0, "recommendations": []}`;
    const result = await invokeGemini(prompt, "You are a climate data validator. Return JSON only.");
    return ok({ success: true, validation_result: result });
  } catch (e) {
    return err(e.message);
  }
}
async function handleUploadToS3(event) {
  const { fileName, content, contentType = "application/json" } = parseBody(event);
  try {
    await s3.send(new import_client_s3.PutObjectCommand({
      Bucket: S3_DATA_BUCKET,
      Key: `uploads/${fileName}`,
      Body: Buffer.from(content, "utf-8"),
      ContentType: contentType
    }));
    const url = `https://${S3_DATA_BUCKET}.s3.${REGION}.amazonaws.com/uploads/${fileName}`;
    return ok({ success: true, url, bucket: S3_DATA_BUCKET });
  } catch (e) {
    return err(e.message);
  }
}
var handler = async (event, _context) => {
  const httpMethod = event.httpMethod ?? event.requestContext?.http?.method ?? "GET";
  const rawPath = event.rawPath ?? event.path ?? "/";
  const path = rawPath.replace(/^(\/[^/]+)?\/climateai-backend/, "") || "/";
  if (httpMethod === "OPTIONS") {
    return ok({}, 200);
  }
  try {
    if (path === "/" || path === "") return handleRoot();
    if (path === "/health") return handleHealth();
    if (path === "/api/kpis") return handleGetKPIs();
    if (path === "/api/interventions") return handleGetInterventions();
    if (path === "/api/alerts" && httpMethod === "GET") return handleGetAlerts(event);
    if (path === "/api/alerts/create") return handleCreateAlert(event);
    if (path === "/api/alerts/notify") return handleNotifyAlert(event);
    if (path === "/api/chat") return handleChat(event);
    if (path === "/api/action-plan/generate") return handleGenerateActionPlan(event);
    if (path === "/api/data/validate") return handleValidateData(event);
    if (path === "/api/data/upload") return handleUploadToS3(event);
    return err(`Route not found: ${httpMethod} ${path}`, 404);
  } catch (e) {
    return err(`Internal server error: ${e.message}`);
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
